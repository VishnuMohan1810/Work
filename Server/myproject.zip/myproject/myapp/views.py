from django.shortcuts import render
from rest_framework.decorators import api_view
from .serializers import UserSerialiser,BlogSerializer
from rest_framework.response import Response
from django.contrib.auth import authenticate
from myapp.models import User,BlogPost
from rest_framework import status


@api_view(['POST'])
def register(request):
    print(request.data)
    regdata = UserSerialiser(data=request.data)
    if regdata.is_valid():
        regdata.save()
        return Response({'status':1,"values":regdata.data})
    else:
        return Response({'status':0,"values":"faield"})


@api_view(['POST'])
def loginfn(request):
    print(request.data)
    username = request.data.get("username")
    password = request.data.get("password")
    # user = authenticate(username=username, password=password)
    user = User.objects.get(username=username, password=password)
    print(user,"-------------")
    if user is not None:
        user_data = UserSerialiser(user).data
        return Response({'status': 1, 'values': user_data})
    else:
        return Response({'status': 0, 'values': "Login failed. Invalid credentials"})
# View All Blogs or Create a New Blog

@api_view(['POST'])
def add_blog(request):
    print(request.data)
    blog = BlogSerializer(data=request.data)
    if blog.is_valid():
        blog.save()
        return Response({'status':1,"values":blog.data})
    else:
        return Response({'status':0,"values":"faield"})

@api_view(['GET'])
def view_blog(request):
    blogs = BlogPost.objects.all()
    serializer = BlogSerializer(blogs, many=True)
    return Response({"data":serializer.data})


# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def add_comment(request, post_id):
#     """
#     Function-based view to handle adding comments to a blog post.
#     """
#     post = get_object_or_404(BlogPost, id=post_id)

#     data = request.data
#     data['author'] = request.user.id
#     data['blog_post'] = post.id

#     serializer = CommentSerializer(data=data)
#     if serializer.is_valid():
#         serializer.save()
#         return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
#     return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['POST'])
# def add_comment(request):
#     print(request.data)
#     comment_data = CommentSerializer(data=request.data)
#     if comment_data.is_valid():
#         comment_data.save()
#         return Response({'status': 1, 'values': comment_data.data})
#     else:
#         return Response({'status': 0, 'values': "Failed to add comment"})

# @api_view(['GET'])
# def view_comments(request, blog_id):
#     comments = Comment.objects.filter(blog_post=blog_id)
#     serializer = CommentSerializer(comments, many=True)
#     return Response({"data": serializer.data})

# Edit a blog post
# @api_view(['PUT'])
# def edit_blog(request, blog_id):
#     try:
#         blog = BlogPost.objects.get(id=blog_id)
#         serializer = BlogSerializer(blog, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#     except BlogPost.DoesNotExist:
#         return Response({"error": "Blog not found"}, status=status.HTTP_404_NOT_FOUND)
    

# # Delete a blog post
# @api_view(['DELETE'])
# def delete_blog(request, blog_id):
#     try:
#         blog = BlogPost.objects.get(id=blog_id)
#         blog.delete()
#         return Response({"message": "Blog deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
#     except BlogPost.DoesNotExist:
#         return Response({"error": "Blog not found"}, status=status.HTTP_404_NOT_FOUND)



@api_view(['PUT'])
def edit_blog(request, blog_id):
    try:
        blog = BlogPost.objects.get(id=blog_id)

        # Ensure the logged-in user is the author of the blog
        if blog.author.id != request.data.get("user_id"):  # Assuming user_id is sent in the request
            return Response({"error": "You are not authorized to edit this post."}, status=status.HTTP_403_FORBIDDEN)

        serializer = BlogSerializer(blog, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    except BlogPost.DoesNotExist:
        return Response({"error": "Blog not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['DELETE'])
def delete_blog(request, blog_id):
    try:
        blog = BlogPost.objects.get(id=blog_id)

        # Ensure the logged-in user is the author of the blog
        if blog.author.id != request.data.get("user_id"):  # Assuming user_id is sent in the request
            return Response({"error": "You are not authorized to delete this post."}, status=status.HTTP_403_FORBIDDEN)

        blog.delete()
        return Response({"message": "Blog deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
    except BlogPost.DoesNotExist:
        return Response({"error": "Blog not found"}, status=status.HTTP_404_NOT_FOUND)

# Add a comment to a blog post
# @api_view(['POST'])
# def add_comment(request, blog_id):
#     try:
#         blog = BlogPost.objects.get(id=blog_id)
#         request.data['post'] = blog.id  # Associate comment with the blog
#         serializer = CommentSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#     except BlogPost.DoesNotExist:
#         return Response({"error": "Blog not found"}, status=status.HTTP_404_NOT_FOUND)