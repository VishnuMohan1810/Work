from rest_framework import serializers
from myapp.models import User,BlogPost
from django.db.models import fields

class UserSerialiser(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ("id","first_name","last_name","email","mobilenumber","gender","password","username")

class BlogSerializer(serializers.ModelSerializer):
    class Meta:
        model = BlogPost
        fields = ['id', 'title', 'content','created_at']


# class CommentSerializer(serializers.ModelSerializer):
#     author_name = serializers.ReadOnlyField(source='author.username')  # For readable author names

#     class Meta:
#         model = Comment
#         fields = ['id', 'blog_post', 'author', 'author_name', 'content', 'created_at']

# class CommentSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Comment
#         fields = ['id', 'blog_post', 'user', 'content', 'created_at']


# class CommentSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Comment
#         fields = ['id', 'post','author','content', 'created_at']

# class BlogPostSerializer(serializers.ModelSerializer):
#     author_name = serializers.ReadOnlyField(source="author.username")
#     comments = serializers.StringRelatedField(many=True, read_only=True)

#     class Meta:
#         model = BlogPost
#         fields = ["id", "title", "content", "author", "author_name", "created_at", "updated_at", "comments"]

# class CommentSerializer(serializers.ModelSerializer):
#     author_name = serializers.ReadOnlyField(source="author.username")

#     class Meta:
#         model = Comment
#         fields = ["id", "post", "author", "author_name", "content", "created_at"]